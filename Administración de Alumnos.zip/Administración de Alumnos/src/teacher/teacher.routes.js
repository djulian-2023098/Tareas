import { Router } from "express";
import { UserValidator } from "../../middlewares/validator.js";
import { deleteT, loginT, postTeacher, updateT, viewCourseT } from "./teacher.controller.js";
import { validateJwt } from "../../middlewares/validate.jwt.js";

const api = Router()

api.post('/addTeacher', UserValidator, postTeacher)
api.post('/loginT',loginT)
api.get('/getTeacher/:id', validateJwt(['TEACHER_ROLE', 'STUDENT_ROLE']), viewCourseT)
api.put('/updateTeacher/:id', validateJwt(['TEACHER_ROLE']), updateT)
api.delete('/deleteTeacher/:id', validateJwt(['TEACHER_ROLE']), deleteT)

export default api  