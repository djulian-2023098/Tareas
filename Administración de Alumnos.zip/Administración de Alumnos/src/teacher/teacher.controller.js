import Teacher from '../teacher/teacher.model.js'
import { checkPassword, encrypt } from '../../utils/encryp.js'
import { generateJwt } from '../../utils/jwt.js'

export const postTeacher = async (req,res)=>{
    try {
        let {course = [], ...data}=req.body

        if(!Array.isArray(course)){
            course = [course]
        }

        const teacher = new Teacher(data)

        course = course.map(c => c.trim().toLowerCase())

        if (new Set(course).size !== course.length) {
            return res.status(400).send(
                { 
                    success: false, 
                    message: "You have duplicate courses" 
                }
            );
        }

        teacher.password = await encrypt(teacher.password)

        await teacher.save()

        return res.send({message:`Registered successfully, can be logged with username, ${teacher.username}`})
    } catch (error) {
        console.error(error)
        return res.status(500).send({message: 'General error with user registration'})
    }
}

export const loginT = async(req,res)=>{
    try{
        let {teacherLoggin,password}=req.body
        let teacher=await Teacher.findOne({
            $or:[
                {email:teacherLoggin},
                {username:teacherLoggin}
            ]
        });
        
        if(teacher && await checkPassword(teacher.password,password)){
            let loggedTeacher={
                id: teacher._id,
                username: teacher.username,
                name:teacher.name,
                role:teacher.role
            }

            const token = await generateJwt(loggedTeacher)
            return res.send(
                {
                    message:`Welcome ${teacher.name}`,
                    loggedTeacher,
                    token
                }
            )
        }
        return res.status(400).send({message:'Invalid Credentials'})
    }catch(error){
        console.error(error)
        return res.status(500).send({message: 'General error with login funtion',e})
    }
}

export const viewCourseT = async (req, res) => {
    try {
        const { id } = req.params;

        const teacher = await Teacher.findById(id).populate('course'); 
        if (!teacher ) {
            return res.status(404).send({
                success: false,
                message: 'Teacher not found'
            });
        }
        return res.status(200).send({
            success: true,
            message: 'Teacher and course found',
            courses: teacher.course,
            teacher
            
        });
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Internal server error', e });
    }
};

export const updateT = async(req,res)=>{
    try{
        const {id}=req.params
        const data=req.body
        const updateTeacher = await Teacher.findByIdAndUpdate(id,data,{new:true})
        if(!updateTeacher) return res.status(400).send({message:'Teacher not found'})
            return res.send({message:'Teacher updated successfully', updateTeacher})
    }catch(error){
        console.error(error)
        return res.status(500).send({message: 'Internal Server Error', error})
    }
}

export const deleteT = async(req,res)=>{
    try{
        const {id}=req.params
        const data=req.body
        const updateTeacher = await Teacher.findByIdAndDelete(id,data,{new:true})
        if(!updateTeacher) return res.status(400).send({message:'User not found'})
            return res.send({message:'User deleted successfully', updateTeacher})
    }catch(error){
        console.error(error)
        return res.status(500).send({message: 'Internal Server Error', e})
    }
}