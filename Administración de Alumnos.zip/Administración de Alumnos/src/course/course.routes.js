import { Router } from "express";
import {agregar, deleteCourse, updateCourse } from "./course.controller.js";
import { courseValidator } from "../../middlewares/validator.js";
import { validateJwt } from "../../middlewares/validate.jwt.js";

const api=Router();

api.post('/addCourse', courseValidator, agregar)
api.put('/updateCourse/:id',validateJwt(['TEACHER_ROLE']),updateCourse)
api.delete('/deleteCourse/:id',validateJwt(['TEACHER_ROLE']),deleteCourse)


export default api;