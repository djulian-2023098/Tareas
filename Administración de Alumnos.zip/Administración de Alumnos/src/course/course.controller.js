import Course from "./course.model.js";
import User from '../Student/student.model.js'
import Teacher from '../teacher/teacher.model.js'

export const agregar = async(req,res)=>{
    try{
        let data=req.body;
        let course = new Course(data)
        await course.save()
        return res.status(200).send(
            {
                sucess:true,
                message:'Course saved succesfully',
                course  
            }
        )
    }catch(error){
        console.error(error)
        return res.status(500).send({message:'Internal server Error',error})
    }
}

export const getAll = async(req,res)=>{
    try{
        const coursesList = await Course.find()
        if(coursesList.length===0){
            return res.status(404).send(
                {
                    succes:false,
                    message:'No courses available yet'
                }
            )
        }
        return res.status(200).send(
            {
                succes:true,
                message: 'Courses Available',
                coursesList
            }
        )
    }catch(error){
        console.error(error)
        return res.status(500).send({message:'Internal Server Error',error})
    }
}


export const updateCourse = async (req, res) => {
    try {
        const { id } = req.params;
        const teacherId = req.user.id; 
        const data = req.body;
        const teacher = await User.findById(Teacher);
        if (!teacher.course || !teacher.course.includes(id)) {
            return res.status(403).send({
                success: false,
                message: 'Forbidden: You are not assigned to this course'
            });
        }
        const updatedCourse = await Course.findByIdAndUpdate(id, data, { new: true });

        if (!updatedCourse) {
            return res.status(404).send({
                success: false,
                message: 'Course not found'
            });
        }
        return res.status(200).send({
            success: true,
            message: 'Course updated successfully',
            course: updatedCourse
        });
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Internal Server Error', error });
    }
};

export const deleteCourse = async (req, res) => {
    try {
        const { id } = req.params;
        const teacherId = req.user.id; 
        const teacher = await User.findById(teacherId);
        if (!teacher.course || !teacher.course.includes(id)) {
            return res.status(403).send({
                success: false,
                message: 'You are not assigned to this course'
            });
        }
        const deleteCourse = await Course.findByIdAndDelete(id);

        if (!deleteCourse) {
            return res.status(404).send({
                success: false,
                message: 'Course not found'
            });
        }
        return res.status(200).send({
            success: true,
            message: 'Course updated successfully',
        });
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Internal Server Error', error });
    }
};

