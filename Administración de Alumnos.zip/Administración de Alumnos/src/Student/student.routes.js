import { Router } from "express";
import { UserValidator } from "../../middlewares/validator.js";
import { add, deleteU, login, update, viewCourse } from "./student.controller.js";
import { validateJwt } from "../../middlewares/validate.jwt.js";

const api = Router();

api.post('/addStudent', UserValidator,add)
api.post('/login',login)
api.get('/get/:id', validateJwt(['TEACHER_ROLE', 'STUDENT_ROLE']), viewCourse)
api.put('/update/:id',validateJwt(['STUDENT_ROLE']),update)
api.delete('/delete/:id',validateJwt(['STUDENT_ROLE']),deleteU)

export default api;