import User from './student.model.js'
import { checkPassword, encrypt } from '../../utils/encryp.js'
import { generateJwt } from '../../utils/jwt.js'


export const add = async(req,res)=>{
    try{
        let {course = [], ...data}=req.body

        if(!Array.isArray(course)){
            course = [course]
        }

        const user = new User(data)
        
        user.course = course;
        if(user.course.length>3){
            return res.status(400).send(
                {
                    succes:false,
                    message:`You cannot be asignend more than 3 courses`
                }
            )
        }

        course = course.map(c => c.trim().toLowerCase());

        if (new Set(course).size !== course.length) {
            return res.status(400).send(
                { 
                    success: false, 
                    message: "You have duplicate courses" 
                }
            );
        }
        user.password = await encrypt(user.password)
        await user.save()
        return res.send({message:`Registered successfully, can be logged with username, ${user.username}`})
    }catch(error){
        console.error(error)
        return res.status(500).send({message: 'General error with user registration'})
    }
}

export const login=async(req,res)=>{
    try{
        let {userLoggin,password}=req.body
        let user=await User.findOne({
            $or:[
                {email:userLoggin},
                {username:userLoggin}
            ]
        });
        
        if(user && await checkPassword(user.password,password)){
            let loggedUser={
                id: user._id,
                username: user.username,
                name:user.name,
                role:user.role
            }

            const token = await generateJwt(loggedUser)
            return res.send(
                {
                    message:`Welcome ${user.name}`,
                    loggedUser,
                    token
                }
            )
        }
        return res.status(400).send({message:'Invalid Credentials'})
    }catch(error){
        console.error(error)
        return res.status(500).send({message: 'General error with login funtion',e})
    }
}

export const viewCourse = async (req, res) => {
    try {
        const { id } = req.params;

        const user = await User.findById(id).populate('course'); 
        if (!user ) {
            return res.status(404).send({
                success: false,
                message: 'User not found'
            });
        }
        return res.status(200).send({
            success: true,
            message: 'User and course found',
            courses: user.course,
            
        });
    } catch (error) {
        console.error(error);
        return res.status(500).send({ message: 'Internal server error', e });
    }
};


export const update = async(req,res)=>{
    try{
        const {id}=req.params
        const data=req.body
        const updatedUser = await User.findByIdAndUpdate(id,data,{new:true})
        if(!updatedUser) return res.status(400).send({message:'User not found'})
            return res.send({message:'User updated successfully', updatedUser})
    }catch(error){
        console.error(error)
        return res.status(500).send({message: 'Internal Server Error', error})
    }
}

export const deleteU = async(req,res)=>{
    try{
        const {id}=req.params
        const data=req.body
        const updatedUser = await User.findByIdAndDelete(id,data,{new:true})
        if(!updatedUser) return res.status(400).send({message:'User not found'})
            return res.send({message:'User deleted successfully', updatedUser})
    }catch(error){
        console.error(error)
        return res.status(500).send({message: 'Internal Server Error', e})
    }
}